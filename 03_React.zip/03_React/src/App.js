import React from 'react';
import AllProductsPage from './components/AllProductsPage';
import {BrowserRouter,Switch,Route,NavLink} from 'react-router-dom';
import './App.css' ;

export default class App extends React.Component {
    render() {
        const About=()=>(
            <div>
                <h1>About : This application provides information about the products </h1>
            </div>
        );
        
        const Header = ()=>(
            <header>
                <NavLink to="/" exact={true} activeClassName="is-active" >About</NavLink>
                <NavLink to="/products" exact={true} activeClassName="is-active" >Products</NavLink>
            </header>
        );

        return (
            <BrowserRouter>
                <Header/>
                <Switch>
                    <Route path="/" exact component={About}/>
                    <Route path="/products" exact={true} component={AllProductsPage}/>
                </Switch>
            </BrowserRouter>
        );
    }
}
