import React from 'react';
import { Link } from 'react-router-dom';
import ProductList from './ProductList';
import ProductStore from '../stores/ProductStore';
import InitializeActions from '../actions/InitializeActions';

export default class AllProductsPage extends React.Component {
    constructor(props) {
      super(props);
      this._onChange = this._onChange.bind(this);

// F1:
      this.state = {
        products: ProductStore.getAllProducts()
      }

    }

    componentDidMount() {
        ProductStore.addChangeListener(this._onChange);
        InitializeActions.initProducts(); 
    }

    _onChange() {
        this.setState({ products: ProductStore.getAllProducts() });
    }

    render() {
        return (
            <div>
                <h1>Product List</h1>
                <ProductList products={this.state.products} />
                <br/>
                <Link to="/addProduct">Add Product</Link>
            </div>
        );
    }
}
