import React from 'react';
import Product from './Product';

export default class ProductList extends React.Component {
  render () {

    let productNodes = this.props.products.map(product => (
        <Product key={product.id} id={product.id} name={product.name} quantity={product.quantity} price={product.price}/>
    ));

    return (
      <>
        <table border="1">
          <thead>
            <tr>
              <th>ID</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {productNodes}
          </tbody>
        </table>
      </>
    );
  }
}
