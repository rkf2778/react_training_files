// eslint-disable-next-line
import _ from 'lodash';
import axios from 'axios';

// eslint-disable-next-line
const _clone = function(item) {
	return JSON.parse(JSON.stringify(item)); //return cloned copy so that the item is passed by value instead of by reference
};

export default class ProducttApi {
	static  getAllProducts() {
		return axios.get('http://localhost:4000/products').then(response=>response.data);
	}

	static saveProduct(product) {
		return axios.post('http://localhost:4000/products',product).then(res=>res.data);
	}
}
