import React from "react";
import { mount, shallow } from "enzyme";
import toJson from 'enzyme-to-json';
import Product from "./Product";
import ProductList from "./ProductList";

describe("When valid array props passed to Prodcut List component", () => {
  let wrapper;
  let props;

  beforeEach(() => {
    props = {
      products: [
        {
          id: 1,
          name: "Moto G5",
          quantity: 2,
          price: 13000,
        },
        {
          id: 2,
          name: "Racold Geyser",
          quantity: 3,
          price: 6000,
        },
        {
          id: 3,
          name: "Dell Inspiron",
          quantity: 4,
          price: 50000,
        },
      ],
    };
    wrapper = shallow(<ProductList {...props} />);
  });

  it('renders "Product Name" as heading in second column ', () => {
    let head = wrapper.find('th').map(col=>col.text());
    expect(head[1]).toContain('Product Name');
  });

  it('renders "Price" as heading in fourth column ', () => {
    let head = wrapper.find('th').map(col=>col.text());
    expect(head[3]).toContain('Price');
  });

  it("passes the 2nd Product's name as props to second Component", () => {
    let data =  (wrapper.find(Product));
    expect(toJson(data)[1].node.props.name).toEqual('Racold Geyser');
  });

  it("passes the 2nd Product's price as props to second Component", () => {
    let data =  (wrapper.find(Product));
    expect(toJson(data)[1].node.props.price).toEqual(6000);
  });

});

describe("When products array props passed to Product List component is null", () => {
  let wrapper;
  let props;

  beforeEach(() => {
    props = { products: null };
    wrapper = shallow(<ProductList {...props} />);
  });

  it("should not crash and no Product Componet is rendered", () => {
    let head = wrapper.find('th').map(col=>col.text());
    expect(head).toEqual([ 'ID', 'Product Name', 'Quantity', 'Price' ]);

    let body = wrapper.find('tbody');
    expect(body.find('tr').length).toEqual(0);
  });
});
