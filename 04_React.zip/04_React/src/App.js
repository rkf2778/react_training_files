import React from 'react';
import {BrowserRouter as Router, Route, Switch, NavLink} from 'react-router-dom';
import AllProductsPage from './components/AllProductsPage';
import AddProductPage from './components/AddProductPage';
import ProductDetail from './components/ProductDetail';
import './App.css'

export default class App extends React.Component {
  render() {

       const About=()=>(
              <div>
                  <h1>About : This application provides information about the products(Using FLUX) </h1>
              </div>
      );

      const Header = ()=>(
        <header>
            <NavLink to="/about" activeClassName="is-active" >About</NavLink>
            <NavLink to="/" exact={true} activeClassName="is-active" >Products</NavLink>
        </header>
    );

      return (
        <Router>
            <Header/>
            <Switch>
              <Route path="/" exact={true} component={AllProductsPage} />
              <Route path="/about"  component={About}/>
              <Route path="/addProduct" component={AddProductPage} />
              <Route path="/ProductDetail" component={ProductDetail}/>
            </Switch>
        </Router>
      );
  }
}
