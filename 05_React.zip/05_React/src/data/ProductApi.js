import axios from 'axios';

const ProductApi=(cb)=> {
	getAllProducts(cb);
	function getAllProducts(cb) {
		axios.get('http://localhost:4000/products')
			.then(response => cb(response.data))
			.catch(error => { throw error });
	}
}

export default ProductApi;
