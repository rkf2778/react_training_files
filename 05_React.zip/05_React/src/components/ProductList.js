import React from 'react';
import Product from './Product';

const ProductList =(props)=>{
  var productNodes = props.products.map(product => (
        <Product key={product.id} id={product.id} name={product.name} quantity={product.quantity} price={product.price}/>
    ));
    return (
      <>
        <table border='1'>
          <thead>
            <tr>
              <th>ID</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {productNodes}
          </tbody>
        </table>
      </>
    )
}
export default ProductList;