export const INITIALIZE = 'INITIALIZE';
export const ADD_PRODUCT = 'ADD_PRODUCT';
