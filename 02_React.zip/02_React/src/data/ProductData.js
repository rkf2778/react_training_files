export default {
  products:
  [
    {
      "id": 1,
      "name": "Moto G5",
      "quantity": 2,
      "price":13000
    },
    {
      "id": 2,
      "name": "Racold Geyser",
      "quantity":3,
      "price":6000
    },
    {
      "id": 3,
      "name": "Dell Inspiron",
      "quantity": 4,
      "price":50000
    }
  ]
};
