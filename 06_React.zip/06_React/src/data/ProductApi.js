import axios from 'axios';


export default class ProducttApi {
	static  getAllProducts() {
		return axios.get('http://localhost:4000/products').then(response=>response.data);
	}

	static saveProduct(product) {
		return axios.post('http://localhost:4000/products',product).then(res=>res.data);
	}
}
