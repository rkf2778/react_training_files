import React from 'react';
import {Link} from 'react-router-dom';
import {Prompt} from 'react-router';

export default class Comment extends React.Component {
  // eslint-disable-next-line
  constructor(props) {
    super(props);
  }


  render() {
    return (
     
     <tr>
     <Prompt message={location =>location.pathname.includes("/ProductDetail")?  `Are you sure you want to view the details ?` : true  } />
        <td>
        
          <Link to={{pathname: "/ProductDetail",productName:{name : this.props.name}}}> 
            {this.props.name} 
          </Link>
        </td>
        <td>{this.props.quantity}</td>
        <td>Rs. {this.props.price}</td>
      </tr>
    );
  }
}
