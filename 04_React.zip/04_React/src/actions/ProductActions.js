import Dispatcher from "../dispatcher/Dispatcher";
import ProductApi from "../data/ProductApi";
import * as ActionTypes from "../constants/ActionTypes";

export default class ProductActions {
  static addProduct(product) {
    return ProductApi.saveProduct(product)
      .then((product) => {
                            Dispatcher.dispatch({
                            actionType: ActionTypes.ADD_PRODUCT,
                            product: product,
                            });
                         })
      .catch((err) => {
        console.error("err", err);
      });
  }
}
