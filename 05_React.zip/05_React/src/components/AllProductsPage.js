import React,{useState,useEffect} from 'react';
import ProductList from './ProductList';
import ProductApi from '../data/ProductApi';

const AllProductsPage = (props)=> {
  const [products,setProduct] = useState([]);
  useEffect(() => {
    ProductApi(data => setProduct(data))
  },[]);
  
  return  (
      <>
          <h1>Product List(Using Functional Components)</h1>
          <ProductList products={products} />
      </>
    );
}

export default AllProductsPage;