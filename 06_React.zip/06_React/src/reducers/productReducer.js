import * as ActionTypes from '../actions/ActionTypes';
import initialState from './initialState';

export default function productReducer(state = initialState.products, action) {
  switch (action.type) {
    case ActionTypes.INITIALIZE:
      return action.product;

    case ActionTypes.ADD_PRODUCT:
      return [
        ...state,
        Object.assign({}, action.product)
      ];

    default:
      return state;
  }
}
