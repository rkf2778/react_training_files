import ProductData from './ProductData';

export default class CommentApi {
	static getAllProducts() {
	    return ProductData.products;
	}
}
