import React from "react";
import { Formik } from "formik";
import * as Yup from "yup";

const validationSchema = Yup.object({
  name: Yup.string().required("Product Name is required"),
  quantity: Yup.number().required("Quantity is required"),
  price: Yup.number().required("Price is required"),
});

export default class ProductForm extends React.Component {
  render() {
    return (
      <Formik
        initialValues={{ name: "", quantity: "", price: "" }}
        validationSchema={validationSchema}
        onSubmit={(value) => {
          var product = {};
          product.name = value.name;
          product.quantity = value.quantity;
          product.price = value.price;
          this.props.onAddProduct(product);
        }}
      >
        {({ handleSubmit, handleChange, values, errors }) => (
          <form onSubmit={handleSubmit}>
            <h1>Add Product - Using Redux</h1>
            Name&nbsp;{" "}
            <input
              type="text"
              onChange={handleChange}
              value={values.name}
              placeholer="Enter Product Name"
              name="name"
            />{" "}
            <span className="is-error">{errors.name}</span>
            <br />
            <br />
            Quantity: &nbsp;{" "}
            <input
              type="number"
              onChange={handleChange}
              value={values.quantity}
              placeholer="Enter Quantity"
              name="quantity"
            />{" "}
            <span className="is-error">{errors.quantity}</span>
            <br />
            <br />
            Price: &nbsp;{" "}
            <input
              type="number"
              step="1"
              onChange={handleChange}
              value={values.price}
              placeholer="Enter Price"
              name="price"
            />{" "}
            <span className="is-error">{errors.price}</span>
            <br />
            <br />
            <button type="submit">Submit</button>
          </form>
        )}
      </Formik>
    );
  }
}
