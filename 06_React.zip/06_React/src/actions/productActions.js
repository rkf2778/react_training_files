import ProductApi from '../data/ProductApi';
import * as ActionTypes from './ActionTypes';


//======================LOADING A PRODUCT
export function loadProductSuccess(product) {
    return { type: ActionTypes.INITIALIZE, product};
  }
  
  export function loadProduct(product){
    return function(dispatch) {
      return ProductApi.getAllProducts(product).then(product => {
        dispatch(loadProductSuccess(product));
      }).catch(error => {
        throw(error);
      });
    };
  }
  //==========================ADDING A PRODUCT
  export function addProductSuccess(product) {
    return { type: ActionTypes.ADD_PRODUCT, product};
  }
  
  export function addProduct(product){
    return function(dispatch) {
      return ProductApi.saveProduct(product).then(product => {
        dispatch(addProductSuccess(product));
      }).catch(error => {
        throw(error);
      });
    };
  }
  
  