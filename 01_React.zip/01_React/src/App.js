import React from 'react';

class App extends React.Component{
    constructor(props){
        super(props);
        this.addOne=this.addOne.bind(this);
        this.minusOne=this.minusOne.bind(this);
        this.state={
            count : 0
        };
    }
    addOne(){
        this.setState((prevState)=>{
            return{
                count : prevState.count + 1
            }
        })
    }
    minusOne(){
        this.setState((prevState)=>{
            return{
                count : prevState.count - 1
            }
        })
    }
    render(){
        return(
            <div>
                <h1>Counter Demo</h1>
                <h2>Count:{this.state.count}</h2>
                <button onClick={this.addOne}>Increment Counter</button>
                <button onClick={this.minusOne}>Decrement Counter</button>
            </div>
        );
    };
}
App.defaultProps ={
    count : 0
}

export default App;
