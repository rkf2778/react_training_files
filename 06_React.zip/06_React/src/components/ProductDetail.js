import React from 'react';
import { Link } from 'react-router-dom';


export default class ProductDetail extends React.Component{
    // eslint-disable-next-line
    constructor(props){
        super(props);
    }

    
    
    render(){
        return(
            <div>
                <h1>Product Details</h1>
                <h3>Product Name : {this.props.location.productName.name}</h3>
                <Link to="/">Back</Link>
            </div>
        );
    }
}