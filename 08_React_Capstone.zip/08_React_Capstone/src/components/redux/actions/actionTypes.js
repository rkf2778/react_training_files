export const INIT = 'INIT';
export const ADD  = 'ADD';
export const DELETE = 'DELETE';
export const UPDATE = 'UPDATE';
export const VIEW = 'VIEW';
export const LOAD_USERS ='LOAD_USERS';
export const ADD_USER = 'ADD_USER';
