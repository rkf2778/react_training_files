import React from "react";
import { withRouter } from "react-router-dom";
import ProductForm from "./ProductForm";
import ProductActions from "../actions/ProductActions";

class AddProductPage extends React.Component {
  constructor(props) {
    super(props);
    this.saveProduct = this.saveProduct.bind(this);
  }

  saveProduct(product) {
    // F2:
    ProductActions.addProduct(product);
    this.props.history.push("/");
  }

  render() {
    return <ProductForm onSave={this.saveProduct} />;
  }
}

export default withRouter(AddProductPage);
