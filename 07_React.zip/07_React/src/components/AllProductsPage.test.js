import React from 'react';
import { mount, shallow } from 'enzyme';
import AllProductsPage from './AllProductsPage';
import ProductList from './ProductList';

describe('All Products Page Snapshot', () => {
    let mountwrapper;
    
    beforeEach(()=>{
        mountwrapper=mount(<AllProductsPage/>);
    })    

    afterEach(()=>{
        mountwrapper.unmount();
    })

    it('renders correctly', () => {
        expect(mountwrapper).toMatchSnapshot();
    });

});


describe('All Products Page rendering of elements', () => {
    let wrapper;

    beforeEach(()=>{
        wrapper=shallow(<AllProductsPage/>);
    })

    afterEach(()=>{
        wrapper.unmount();
    })

    it('renders correct heading for Products List', () => {
        expect(wrapper.find('h1').render().text()).toEqual("Product List");
    });

    it('renders one Product List Component ', () => {
        expect(wrapper.find(ProductList).length).toEqual(1);
    });
});
